<template>
  <div>
    <h2>Home</h2>
    <img center src="./images/BWhealthcloud.png" alt="Center Image" class="centered-image">
  </div>
</template>

<style scoped>
  img{
    display: block;
    margin: auto;
  }
  h2 {
    margin-bottom: 20px;
    font-size: 36px;
  }
  p {
    margin: 20px 0;
  }
  .centered-image {
        justify-content: center;
        max-width: 70%; /* Optionally set max-width to prevent image overflow */
        max-height: 50%; /* Optionally set max-height to prevent image overflow */
}
</style>